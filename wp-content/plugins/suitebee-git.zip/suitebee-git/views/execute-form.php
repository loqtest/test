<div class="suitebee-git-settings suitebee-git-settings--execute-form">
  <div class="form">
    <form action="" method="post" enctype="multipart/form-data">

      <div class="directory-field">
        <?php echo $directory; ?>
      </div>

      <div class="form__block">
        <input type="submit" name="sg-execute-btn" value="Execute SH File" class="button button-primary form__field form__field--execute" />
      </div>

    </form>
  </div>
</div>